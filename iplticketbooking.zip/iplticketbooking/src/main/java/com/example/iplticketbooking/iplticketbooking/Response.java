package com.example.iplticketbooking.iplticketbooking;

public class Response {

  public String message;
  public int status;
}
